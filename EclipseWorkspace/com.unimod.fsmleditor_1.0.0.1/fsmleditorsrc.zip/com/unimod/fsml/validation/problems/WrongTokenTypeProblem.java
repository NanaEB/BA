/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsml.validation.problems; 

import org.eclipse.core.resources.IMarker;
import org.eclipse.ui.IMarkerResolution;

import com.unimod.fsml.validation.ProblemToken;

class WrongTokenTypeProblem extends Problem {
    private static final String DESCRIPTION = "Wrong token type is used.";

    WrongTokenTypeProblem(IMarker marker, ProblemToken p) {
		super(marker, p);
	}
	
	public String getDescription() {
		return DESCRIPTION;
	}
	
	public int getSeverity() {
		return IMarker.SEVERITY_ERROR;
	}

	public boolean hasResolutions() {
		return false;
	}
	
	public IMarkerResolution[] getResolutions() {
		return new IMarkerResolution[0];
	}
}