/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsml.validation.problems;

import org.eclipse.core.resources.IMarker;

import com.unimod.fsml.validation.ProblemToken;

public class ProblemFactory {

    private ProblemFactory() {
    }

    public static ProblemFactory createProblemFactory() {
        return new ProblemFactory();
    }

    public Problem createWrongTokenTypeProblem(IMarker marker, ProblemToken problemToken) {
        return new WrongTokenTypeProblem(marker, problemToken);
    }
}

