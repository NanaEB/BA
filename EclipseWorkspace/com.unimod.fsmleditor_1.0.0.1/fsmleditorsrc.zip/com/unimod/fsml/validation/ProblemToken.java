/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsml.validation;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.unimod.fsml.model.lexer.Token;

public class ProblemToken {
	
	/**
	 * Associated problems property
	 */
	public static final String PROBLEMS_PROPERTY = "PROBLEMS_PROPERTY";

	private Token token;

	transient private PropertyChangeSupport listeners;

	public ProblemToken(Token token) {
		this.token = token;
	}

	public Token getToken() {
		return token;
	}

	/**
	 * Adds new property change listener 
	 * 
	 * @param l property change listener
	 */
	public void addPropertyChangeListener(PropertyChangeListener l){
	  initListeners();
		
	  listeners.addPropertyChangeListener(l);
	}
  
	/**
	 * Removes property change listener 
	 * 
	 * @param l property change listener
	 */
	public void removePropertyChangeListener(PropertyChangeListener l){
	  initListeners();
		  
	  listeners.removePropertyChangeListener(l);
	}

	/**
     * Forces token to notify its listeners about  
     * changes of associated problems. 
     * This method called by {@link com.unimod.fsml.validation.InternalValidator} 
     * in UI thread on every found Problem to force token painting.
     * Property name in fired event must be {@link #PROBLEMS_PROPERTY} 
     */
	public void fireProblemsChanged() {
		firePropertyChange(PROBLEMS_PROPERTY, null, null);
	}
	
  	/**
  	 * Fires property change event 
  	 * 
  	 * @param prop property name
  	 * @param oldValue old property value
  	 * @param newValue new property value
  	 */
	protected void firePropertyChange(String prop, Object oldValue, Object newValue){
  	  initListeners();

	  listeners.firePropertyChange(prop, oldValue, newValue); 
	}

	protected void initListeners() {
		if (listeners == null) {
			listeners = new PropertyChangeSupport(this);	
		}
	}
}
