/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsml.model.transform;

import java.util.List;

import com.evelopers.unimod.core.stateworks.Action;
import com.evelopers.unimod.core.stateworks.Event;
import com.evelopers.unimod.core.stateworks.Guard;
import com.evelopers.unimod.core.stateworks.State;

/**
 * This class stores data without target state for transaction
 * that is not ready to be saved in state machine.
 * 
 * @author Ivan Lagunov
 */
public class UnfinishedTransition {
	/**
	 * Source state 
	 */
	private State sourceState = null;
	
	/**
	 * Trigger events.
	 */
	private List<Event> events = null;

	/**
	 * Output actions.
	 */
	private List<Action> actions = null;
	
	/**
	 * Guard condition
	 */
	private Guard guard = null;

	public UnfinishedTransition(State sourceState, List<Event> events, List<Action> actions, Guard guard) {
		this.sourceState = sourceState;
		this.events = events;
		this.actions = actions;
		this.guard = guard;
	}
	
	public void setSourceState(State sourceState) {
		this.sourceState = sourceState;
	}

	public State getSourceState() {
		return sourceState;
	}

	public void setEvents(List<Event> events) {
		this.events = events;
	}

	public List<Event> getEvents() {
		return events;
	}

	public void setActions(List<Action> actions) {
		this.actions = actions;
	}

	public List<Action> getActions() {
		return actions;
	}

	public void setGuard(Guard guard) {
		this.guard = guard;
	}

	public Guard getGuard() {
		return guard;
	}
}
