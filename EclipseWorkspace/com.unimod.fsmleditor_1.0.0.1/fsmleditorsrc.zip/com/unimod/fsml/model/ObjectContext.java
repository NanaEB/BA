/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsml.model;

import java.util.Iterator;
import java.util.Stack;

import org.eclipse.jdt.internal.core.util.Util;

import com.evelopers.unimod.runtime.ControlledObject;
import com.evelopers.unimod.runtime.context.StateMachineContext;
import com.unimod.fsml.util.COHelper;

/**
 * @author Ivan Lagunov
 */
public class ObjectContext implements ControlledObject {
    
	public enum ContextType {
		DEFAULT, EVENT_PROVIDER, CONTROLLED_OBJECT, EVENT, GUARD, ACTION, STATE
	}
	
    private Stack<String> s = new Stack<String>();
    private boolean idTokenFinished = false;
    private ContextType contextType = ContextType.DEFAULT;

    /**
    * @unimod.action.descr push last token to context
    */
    public void z1(StateMachineContext context) {
        s.push(COHelper.getTokenValue(context));
        idTokenFinished = false;
    }

    /**
    * @unimod.action.descr clear context data
    */
    public void z2(StateMachineContext context) {
    	clearStack();
    }

    /**
     * @unimod.action.descr set default context
     */
    public void z3(StateMachineContext context) {
    	clearStack();
    	contextType = ContextType.DEFAULT;
    }
    
    /**
    * @unimod.action.descr set event context
    */
    public void z4(StateMachineContext context) {
    	clearStack();
    	contextType = ContextType.EVENT;
    }

    /**
    * @unimod.action.descr set guard context
    */
    public void z5(StateMachineContext context) {
    	clearStack();
    	contextType = ContextType.GUARD;
    }
    
    /**
     * @unimod.action.descr set action context
     */
    public void z6(StateMachineContext context) {
    	clearStack();
    	contextType = ContextType.ACTION;
    }

    /**
     * @unimod.action.descr set event provider context
     */
    public void z7(StateMachineContext context) {
    	clearStack();
    	contextType = ContextType.EVENT_PROVIDER;
    }

    /**
     * @unimod.action.descr set controlled object context
     */
    public void z8(StateMachineContext context) {
    	clearStack();
    	contextType = ContextType.CONTROLLED_OBJECT;
    }

    /**
     * @unimod.action.descr set state context
     */
    public void z9(StateMachineContext context) {
    	clearStack();
    	contextType = ContextType.STATE;
    }

	/**
	 * @unimod.action.descr mark id token finished
	 */
	public void z10(StateMachineContext context) {
		idTokenFinished = true;
	}

	public ContextType getContextType() {
		return contextType;
	}

    public boolean isIdTokenFinished() {
    	return idTokenFinished;
    }
    
	/**
	 * Returns the top element of context stack without removing it from stack.
	 * 
	 * @return the top element of context stack.
	 */
	public String peekTopElement() {
		return s.peek();
	}
	
	/**
	 * Returns full Java path created from the sequence of id's in context stack.
	 * 
	 * @return full Java path.
	 */
	public String peekFullJavaPath() {
		StringBuilder sb = new StringBuilder();
		
		for (Iterator<String> iter = s.iterator(); iter.hasNext();) {
			sb.append(iter.next());
			if (iter.hasNext()) {
				sb.append('.');
			}
		}
		
		return sb.toString();
	}
	
	/**
	 * Returns depth of the stack. 
	 * 
	 * @return depth of the stack.
	 */
	public int getStackDepth() {
		return s.size();
	}
	
	private void clearStack() {
        s.clear();
        idTokenFinished = false;
	}
}
