/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsml.model.lexer;

import java.util.Arrays;

import com.unimod.fsml.FSMLTokens;

/**
 * This class represents token used by lexer. 
 */
public class Token {
	private String type;
	private int typeId;
    private String value;
    private int start;
    private int end;
    private int lineNumber;
    private String expr;

    public Token(String type, String value, int start, int end, int lineNumber, String expr) {
    	this.type = type;
        this.typeId = FSMLTokens.Events.getIdByName(type);
        this.value = value;
        this.start = start;
        this.end = end;
        this.lineNumber = lineNumber;
        this.expr = expr;
    }

	public String getType() {
		return type;
	}
	
	public int getTypeId() {
		return typeId;
	}

	public String getValue() {
		return value;
	}

	public int getStart() {
		return start;
	}

	public int getEnd() {
        return end;
    }

    public int getLineNumber() {
		return lineNumber;
	}

	public String getExpr() {
        return expr;
    }

    public String getParsedExpr() {
        return expr.substring(0, end);
    }

    /**
     * Defines if current token should be followed by space character.
     * Used by autocompletion algorithm.
     * 
     * @return true - if current token should be followed with space, false - otherwise.
     */
    public boolean isSpaceFollowed() {
    	return !(Arrays.asList(FSMLTokens.SYNTAX_SIGNS).contains(value) ||
    			Arrays.asList(FSMLTokens.RELATIONS).contains(value)); 
    }
    
	@Override
    public String toString() {
		return type + " = [" + value + "]"; 
	}
}