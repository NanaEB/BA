/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsml.model.lexer;

/**
 * This interface contains parameter names used by {@link FSMLLexer lexer}.
 * 
 * @author Ivan Lagunov
 */
public interface LexerParameters {
	
	String TOKEN = "token";
	
	String EXPRESSION = "expr";
	
	String PARSED_EXPRESSION = "parsedExpr";

	String TOKEN_TYPE = "tokenType";

	String TOKEN_VALUE = "tokenValue";
}
