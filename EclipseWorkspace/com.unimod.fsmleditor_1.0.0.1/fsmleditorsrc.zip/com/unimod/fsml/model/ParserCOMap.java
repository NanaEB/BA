/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsml.model;

import com.evelopers.unimod.core.stateworks.StateMachine;
import com.evelopers.unimod.plugin.eclipse.model.GModel;
import com.evelopers.unimod.plugin.eclipse.property.autocompletion.StreamErrorListener;
import com.evelopers.unimod.runtime.ControlledObject;
import com.evelopers.unimod.runtime.ControlledObjectsMap;
import com.evelopers.unimod.runtime.context.StateMachineContext;
import com.unimod.fsml.model.lexer.FSMLLexer;
import com.unimod.fsml.model.transform.FSMLToModel;

/**
 * @author Ivan Lagunov
 */
public class ParserCOMap implements ControlledObjectsMap {
	private FSMLLexer lexer;
	private Stack stack;
	private FSMLToModel fsmlToModel;
	private ObjectContext objectContext;
	private StreamErrorListener streamErrorListener;

	public ParserCOMap(StateMachine stateMachine, GModel model, StateMachineContext smContext) {
		this.lexer = new FSMLLexer(stateMachine, smContext);
		this.stack = new Stack();
		this.fsmlToModel = new FSMLToModel(model);
		this.objectContext = new ObjectContext();
		this.streamErrorListener = new StreamErrorListener();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.evelopers.unimod.runtime.ControlledObjectsMap#getControlledObject(java.lang.String)
	 */
	public ControlledObject getControlledObject(String coName) {
		if ("o1".equals(coName)) {
			return stack;
		} else if ("o2".equals(coName)) {
			return lexer;
		} else if ("o3".equals(coName)) {
			return fsmlToModel;
		} else if ("o4".equals(coName)) {
			return objectContext;
		} else if ("o5".equals(coName)) {
			return streamErrorListener;
		} else {
			throw new IllegalArgumentException(
					"Unknown controlled object is requested: " + coName);
		}
	}

	/**
	 * @return Returns the lexer.
	 */
	public FSMLLexer getLexer() {
		return lexer;
	}

	/**
	 * @return Returns the stack.
	 */
	public Stack getStack() {
		return stack;
	}

	/**
	 * @return Returns the fsml to model transformer.
	 */
	public FSMLToModel getFsmlToModel() {
		return fsmlToModel;
	}

	/**
	 * @return Returns the object context.
	 */
	public ObjectContext getObjectContext() {
		return objectContext;
	}

	/**
	 * @return Returns the stream error listener.
	 */
	public StreamErrorListener getStreamErrorListener() {
		return streamErrorListener;
	}
}
