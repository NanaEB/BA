/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsml.model;

import java.util.LinkedList;

import com.evelopers.unimod.runtime.ControlledObject;
import com.evelopers.unimod.runtime.context.StateMachineContext;

/**
 * @author Ivan Lagunov
 */
@SuppressWarnings("unused")
public class Stack implements ControlledObject {
	final static private String PARENTHESIS = "parenthesis";	
	final static private String BRACE = "brace";	
	final static private String STATES_TOKEN = "states_token";	
	private LinkedList<String> buffer = new LinkedList<String>();
	
	/**
	 * @unimod.action.descr stack is empty 
	 */
	public boolean x1(StateMachineContext context) {
//		Logger.CONSOLE.info(buffer);
		return buffer.isEmpty(); 
	}

	/**
	 * @unimod.action.descr PARENTHESIS "()" on top 
	 */
	public boolean x2(StateMachineContext context) {		
		return !buffer.isEmpty() && PARENTHESIS.equals(buffer.getLast()); 
	}

	/**
	 * @unimod.action.descr BRACE "{}" on top 
	 */
	public boolean x3(StateMachineContext context) {		
		return !buffer.isEmpty() && BRACE.equals(buffer.getLast()); 
	}

	/**
	 * @unimod.action.descr STATES_TOKEN token on top 
	 */
	public boolean x4(StateMachineContext context) {		
		return !buffer.isEmpty() && STATES_TOKEN.equals(buffer.getLast()); 
	}

	/**
	 * @unimod.action.descr pop 
	 */
	public void z1(StateMachineContext context) {		
		buffer.removeLast(); 
	}

	/**
	 * @unimod.action.descr push PARENTHESIS "()" 
	 */
	public void z2(StateMachineContext context) {		
		buffer.addLast(PARENTHESIS); 
	}	

	/**
	 * @unimod.action.descr push BRACE "{}"
	 */
	public void z3(StateMachineContext context) {		
		buffer.addLast(BRACE); 
	}	

	/**
	 * @unimod.action.descr push STATES_TOKEN token
	 */
	public void z4(StateMachineContext context) {		
		buffer.addLast(STATES_TOKEN); 
	}	
}
