/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsml.model;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.evelopers.unimod.runtime.ControlledObject;
import com.evelopers.unimod.runtime.context.StateMachineContext;

/**
 * @author Ivan Lagunov
 */
@SuppressWarnings("unused")
public class StreamErrorListener implements ControlledObject {
    private static final Log logger = LogFactory.getLog(StreamErrorListener.class);

    /**
    * @unimod.action.descr token was skipped
    */
    public void z1(StateMachineContext context) {
    	logger.debug("Token was skipped");
    }

    /**
    *@unimod.action.descr tokens were added to stream
    */
    public void z2(StateMachineContext context) {
        logger.debug("Tokens were added to stream");
    }
}
