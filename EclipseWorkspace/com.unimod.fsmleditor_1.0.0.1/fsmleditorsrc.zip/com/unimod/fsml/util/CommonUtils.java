/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsml.util;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Utility class that contains common methods.
 *
 * @author Ivan Lagunov
 */
public class CommonUtils {
    private static final Log log = LogFactory.getLog(CommonUtils.class);

	public static String convertStreamToString(InputStream is) {
		StringBuilder sb = new StringBuilder();
	    byte[] b = new byte[4096];
	    try {
			for (int n; (n = is.read(b)) != -1;) {
			    sb.append(new String(b, 0, n));
			}
		} catch (IOException e) {
            log.error("Cannot convert InputStream to String", e);
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                log.error("Cannot close InputStream", e);
            }
		}
	    return sb.toString();
	}	
}
