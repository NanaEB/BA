/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsml.util;

import static com.unimod.fsml.model.lexer.LexerParameters.TOKEN_VALUE;

import com.evelopers.unimod.runtime.context.StateMachineContext;

/**
 * This class provide common functionality for some <code>ControlledObject</code> implementations.
 * 
 * @author Ivan Lagunov
 */
public class COHelper {
	
	/**
	 * Loads token value parameter from given {@link StateMachineContext context}.
	 * 
	 * @param context state machine context to load parameter from.
	 * @return string value of parameter.
	 */
	public static String getTokenValue(StateMachineContext context) {
		return (String) context.getEventContext().getParameter(TOKEN_VALUE);
	}
}
