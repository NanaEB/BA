/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsml;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Ivan Lagunov
 */
public interface FSMLTokens {
	String[] KEYWORDS = { "any", "else", "enter", "execute", "exit", "final", "if", "include", "initial", "on", "statemachine", "transitto", "uses" };
	
	public static class Events {
		private static Map<String, Integer> EVENTS = new HashMap<String, Integer>();
		
		static {
			EVENTS.put(E1_NAME, E1);
			EVENTS.put(E2_NAME, E2);
			EVENTS.put(E3_NAME, E3);
			EVENTS.put(E4_NAME, E4);
			EVENTS.put(E5_NAME, E5);
			EVENTS.put(E6_NAME, E6);
			EVENTS.put(E7_NAME, E7);
			EVENTS.put(E8_NAME, E8);
			EVENTS.put(E9_NAME, E9);
			EVENTS.put(E10_NAME, E10);
			EVENTS.put(E11_NAME, E11);
			EVENTS.put(E12_NAME, E12);
			EVENTS.put(E13_NAME, E13);
			EVENTS.put(E14_NAME, E14);
			EVENTS.put(E15_NAME, E15);
			EVENTS.put(E16_NAME, E16);
			EVENTS.put(E17_NAME, E17);
			EVENTS.put(E18_NAME, E18);
			EVENTS.put(E19_NAME, E19);
			EVENTS.put(E20_NAME, E20);
			EVENTS.put(E21_NAME, E21);
			EVENTS.put(E22_NAME, E22);
			EVENTS.put(E23_NAME, E23);
			EVENTS.put(E24_NAME, E24);
			EVENTS.put(E25_NAME, E25);
			EVENTS.put(E26_NAME, E26);
			EVENTS.put(E27_NAME, E27);
			EVENTS.put(E28_NAME, E28);
			EVENTS.put(E29_NAME, E29);
			EVENTS.put(E30_NAME, E30);
			EVENTS.put(E31_NAME, E31);
			EVENTS.put(E32_NAME, E32);
		}
		
		public static int getIdByName(String key) {
			return EVENTS.get(key);
		} 
	}
	
	/**
	 * @unimod.event.descr comes unresolved token 
	 */
	public static final String E1_NAME = "e1";
	public static final int E1 = 1;
	
	/**
	 * @unimod.event.descr comes type identifier 
	 */
	public static final String E2_NAME = "e2";
	public static final int E2 = 2;
    public interface TYPE {
        String BOOLEAN = "boolean";
        String BYTE = "byte";
        String CHAR = "char";
        String DOUBLE = "double";
        String FLOAT = "float";
        String INT = "int";
        String LONG = "long";
        String SHORT = "short";
        String VOID = "void";
    }
	String[] TYPES = { TYPE.BOOLEAN, TYPE.BYTE, TYPE.CHAR, TYPE.DOUBLE, TYPE.FLOAT, 
            TYPE.INT, TYPE.LONG, TYPE.SHORT, TYPE.VOID };

	/**
	 * @unimod.event.descr comes boolean const 
	 */
	public static final String E3_NAME = "e3";
	public static final int E3 = 3;
    public interface BOOL_CONST {
        String FALSE = "false";
        String TRUE = "true";
    }
	String[] BOOL_CONSTS = { BOOL_CONST.FALSE, BOOL_CONST.TRUE };

	/**
	 * @unimod.event.descr comes integer const 
	 */
	public static final String E4_NAME = "e4";
	public static final int E4 = 4; 

	/**
	 * @unimod.event.descr comes id 
	 */
	public static final String E5_NAME = "e5";
	public static final int E5 = 5; 

	/**
	 * @unimod.event.descr comes and "&&" 
	 */
	public static final String E6_NAME = "e6";
	public static final int E6 = 6; 
	String AND = "&&";
	
	/**
	 * @unimod.event.descr comes or "||"
	 */
	public static final String E7_NAME = "e7";
	public static final int E7 = 7; 
	String OR = "||";
	
	/**
	 * @unimod.event.descr comes rel 
	 */
	public static final String E8_NAME = "e8";
	public static final int E8 = 8;
    public interface RELATION {
    	String GT = ">";
    	String LT = "<";
    	String GTE = ">=";
    	String LTE = "<=";
    	String EQ = "==";
    	String NE = "!=";
    }
    String[] RELATIONS = { RELATION.GT, RELATION.LT, RELATION.GTE,
            RELATION.LTE, RELATION.EQ, RELATION.NE };

	/**
	 * @unimod.event.descr comes eof 
	 */
	public static final String E9_NAME = "e9";
	public static final int E9 = 9;

	/**
	 * @unimod.event.descr comes dot "."
	 */
	public static final String E10_NAME = "e10";
	public static final int E10 = 10;
	String DOT = ".";
	
	/**
	 * @unimod.event.descr comes not "!"
	 */
	public static final String E11_NAME = "e11";
	public static final int E11 = 11;
	String NOT = "!";
	
    /**
     * @unimod.event.descr comes comma ","
     */
	public static final String E12_NAME = "e12";
    public static final int E12 = 12;
	String COMMA = ",";

	/**
     * @unimod.event.descr comes semicolon ";" 
     */
	public static final String E13_NAME = "e13";
    public static final int E13 = 13;
    String SEMICOLON = ";";

    /**
     * @unimod.event.descr comes open brace "{"
     */
	public static final String E14_NAME = "e14";
    public static final int E14 = 14;
	String OPEN_BRACE = "{";

    /**
     * @unimod.event.descr comes close brace "}"
     */
	public static final String E15_NAME = "e15";
    public static final int E15 = 15;
	String CLOSE_BRACE = "}";

    /**
     * @unimod.event.descr comes open parenthesis "("
     */
	public static final String E16_NAME = "e16";
    public static final int E16 = 16;
	String OPEN_PARENTHESIS = "(";

    /**
     * @unimod.event.descr comes close parenthesis ")"
     */
	public static final String E17_NAME = "e17";
    public static final int E17 = 17;
	String CLOSE_PARENTHESIS = ")";

	String[] SYNTAX_SIGNS = new String[] {
			AND, OR, DOT, NOT, COMMA, SEMICOLON,
			OPEN_BRACE, CLOSE_BRACE,
			OPEN_PARENTHESIS, CLOSE_PARENTHESIS
	};	
	
	/**
     * @unimod.event.descr comes initial state type 
     */
	public static final String E18_NAME = "e18";
    public static final int E18 = 18;

    /**
     * @unimod.event.descr comes final state type 
     */
    public static final String E19_NAME = "e19";
    public static final int E19 = 19;
    public interface STATE_TYPE {
        String INITIAL = "initial";
        String FINAL = "final";
    }
    
	/**
     * @unimod.event.descr comes "execute" keyword
     */
    public static final String E20_NAME = "e20";
    public static final int E20 = 20;
    String EXECUTE = "execute";
    
	/**
     * @unimod.event.descr comes "transitto" keyword
     */
    public static final String E21_NAME = "e21";
    public static final int E21 = 21;
    String TRANSITTO = "transitto";

	/**
     * @unimod.event.descr comes "on" keyword
     */
    public static final String E22_NAME = "e22";
    public static final int E22 = 22;
    String ON = "on";
   
	/**
     * @unimod.event.descr comes "statemachine" keyword
     */
    public static final String E23_NAME = "e23";
    public static final int E23 = 23;
    String STATEMACHINE = "statemachine";
    
	/**
     * @unimod.event.descr comes "if" keyword
     */
    public static final String E24_NAME = "e24";
    public static final int E24 = 24;
    String IF = "if";

	/**
     * @unimod.event.descr comes "else" keyword
     */
    public static final String E25_NAME = "e25";
    public static final int E25 = 25;
    String ELSE = "else";

	/**
     * @unimod.event.descr comes enter event type 
     */
    public static final String E26_NAME = "e26";
    public static final int E26 = 26;
    
	/**
     * @unimod.event.descr comes any event type 
     */
    public static final String E27_NAME = "e27";
    public static final int E27 = 27;

	/**
     * @unimod.event.descr comes exit event type 
     */
    public static final String E28_NAME = "e28";
    public static final int E28 = 28;
    public interface EVENT_TYPE {
    	String ANY = "any";
    	String ENTER = "enter";
    	String EXIT = "exit";
    }
    
	/**
     * @unimod.event.descr comes "uses" keyword 
     */
    public static final String E29_NAME = "e29";
    public static final int E29 = 29;
    String USES = "uses";

	/**
     * @unimod.event.descr comes "include" keyword 
     */
    public static final String E30_NAME = "e30";
    public static final int E30 = 30;
    String INCLUDE = "include";

	/**
     * @unimod.event.descr comes blank token
     */
    public static final String E31_NAME = "e31";
    public static final int E31 = 31;

	/**
     * @unimod.event.descr comes comment token 
     */
    public static final String E32_NAME = "e32";
    public static final int E32 = 32;
}
