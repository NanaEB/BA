/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsmleditor;

import org.eclipse.ui.plugin.*;
import org.eclipse.jface.text.rules.RuleBasedScanner;

import com.unimod.fsmleditor.configuration.FSMLColorProvider;
import com.unimod.fsmleditor.configuration.scanner.FSMLCodeScanner;
import com.unimod.fsmleditor.configuration.scanner.FSMLDocScanner;
import com.unimod.fsmleditor.configuration.scanner.FSMLPartitionScanner;

/**
 * The FSML editor plug-in class.
 */
public class FSMLEditorPlugin extends AbstractUIPlugin {

	public final static String FSML_PARTITIONING = "__fsml_partitioning";
	
	//The shared instance.
	private static FSMLEditorPlugin plugin;

	private static FSMLPartitionScanner fPartitionScanner;
	private static FSMLColorProvider fColorProvider;
	private static FSMLCodeScanner fCodeScanner;
	private static FSMLDocScanner fDocScanner;

	/**
	 * Creates a new plug-in instance.
	 */
	public FSMLEditorPlugin() {
		plugin = this;
	}

	/**
	 * Returns the default plug-in instance.
	 * 
	 * @return the default plug-in instance
	 */
	public static FSMLEditorPlugin getDefault() {
		return plugin;
	}

	/**
	 * Return a scanner for creating FSML partitions.
	 * 
	 * @return a scanner for creating FSML partitions
	 */
	 public static FSMLPartitionScanner getFSMLPartitionScanner() {
		if (fPartitionScanner == null)
			fPartitionScanner= new FSMLPartitionScanner();
		return fPartitionScanner;
	}

	/**
	 * Returns the singleton FSML code scanner.
	 * 
	 * @return the singleton FSML code scanner
	 */
	 public static RuleBasedScanner getFSMLCodeScanner() {
	 	if (fCodeScanner == null)
			fCodeScanner = new FSMLCodeScanner(getFSMLColorProvider());
		return fCodeScanner;
	}
	
	/**
	 * Returns the singleton FSML color provider.
	 * 
	 * @return the singleton FSML color provider
	 */
	 public static FSMLColorProvider getFSMLColorProvider() {
	 	if (fColorProvider == null)
			fColorProvider = new FSMLColorProvider();
		return fColorProvider;
	}
	
	/**
	 * Returns the singleton FSMLdoc scanner.
	 * 
	 * @return the singleton FSMLdoc scanner
	 */
	 public static RuleBasedScanner getFSMLDocScanner() {
	 	if (fDocScanner == null)
			fDocScanner = new FSMLDocScanner(fColorProvider);
		return fDocScanner;
	}
}
