/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsmleditor.configuration;

import org.eclipse.jface.contentassist.IContentAssistSubjectControl;
import org.eclipse.jface.contentassist.ISubjectControlContentAssistProcessor;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.TextPresentation;
import org.eclipse.jface.text.contentassist.ContextInformation;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.contentassist.IContextInformation;
import org.eclipse.jface.text.contentassist.IContextInformationPresenter;
import org.eclipse.jface.text.contentassist.IContextInformationValidator;
import org.eclipse.swt.SWTException;

import com.evelopers.common.exception.CommonException;
import com.evelopers.common.util.helper.StringHelper;
import com.unimod.fsml.model.FSMLAutoCompletion;

/**
 * @author Ivan Lagunov
 */
public class FSMLAssistProcessor implements ISubjectControlContentAssistProcessor {

//    private IContextInformationValidator fValidator = new Validator();
    private FSMLAutoCompletion autoCompletion;
   
    /**
     * Simple content assist tip closer. The tip is valid in a range
     * of 5 characters around its popup location.
     */
    protected static class Validator implements IContextInformationValidator, IContextInformationPresenter {

        protected int fInstallOffset;

        /*
         * @see IContextInformationValidator#isContextInformationValid(int)
         */
        public boolean isContextInformationValid(int offset) {
            return Math.abs(fInstallOffset - offset) < 5;
        }

        /*
         * @see IContextInformationValidator#install(IContextInformation, ITextViewer, int)
         */
        public void install(IContextInformation info, ITextViewer viewer, int offset) {
            fInstallOffset = offset;
        }
        
        /*
         * @see org.eclipse.jface.text.contentassist.IContextInformationPresenter#updatePresentation(int, TextPresentation)
         */
        public boolean updatePresentation(int documentPosition, TextPresentation presentation) {
            return false;
        }
    }

    public FSMLAssistProcessor() {
        try {
            autoCompletion = createAutoCompletion();
        } catch (Exception e) {
            throw new SWTException(StringHelper.stackTraceToString(e));
        }
    }
    
    public ICompletionProposal[] computeCompletionProposals(IContentAssistSubjectControl contentAssistSubjectControl, int documentOffset) {
        return computeCompletionProposals(contentAssistSubjectControl.getDocument(), documentOffset);
    }

    public ICompletionProposal[] computeCompletionProposals(ITextViewer viewer, int offset) {
        return computeCompletionProposals(viewer.getDocument(), offset);
    }
    
    private ICompletionProposal[] computeCompletionProposals(IDocument document, int offset) {
        String expr = document.get();

        try {
            return autoCompletion.autoComplete(expr, offset);
        } catch (Exception e) {
            e.printStackTrace();
            return new ICompletionProposal[0];
        }
    }

    public IContextInformation[] computeContextInformation(
            IContentAssistSubjectControl contentAssistSubjectControl, int documentOffset) {
/*        IContextInformation[] result = new IContextInformation[5];
        for (int i = 0; i < result.length; i++)
            result[i] = new ContextInformation(
                MessageFormat.format(FSMLEditorMessages.getString("CompletionProcessor.ContextInfo.display.pattern"), new Object[] { new Integer(i), new Integer(documentOffset) }),
                MessageFormat.format(FSMLEditorMessages.getString("CompletionProcessor.ContextInfo.value.pattern"), new Object[] { new Integer(i), new Integer(documentOffset - 5), new Integer(documentOffset + 5)}));
        return result;
*/
    	return new IContextInformation[]{
            new ContextInformation("ContextDisplayString", "InformationDisplayString"),
        };
    }

    public IContextInformation[] computeContextInformation(ITextViewer viewer, int offset) {
    	return new IContextInformation[]{
            new ContextInformation("ContextDisplayString", "InformationDisplayString"),
        };
//        throw new UnsupportedOperationException();
    }

    public char[] getCompletionProposalAutoActivationCharacters() {
        return new char[]{'.', '('};
    }

    public char[] getContextInformationAutoActivationCharacters() {
        return new char[]{'#'};
    }

    public String getErrorMessage() {
        return "Error Message";
    }

    public IContextInformationValidator getContextInformationValidator() {
//        return fValidator;
        return null;
    }

    /**
     * Creates new automata completion engine.
     * 
     * @return completion engine.
     * @throws CommonException 
     */
    private FSMLAutoCompletion createAutoCompletion() {
        return new FSMLAutoCompletion();
    }
}
