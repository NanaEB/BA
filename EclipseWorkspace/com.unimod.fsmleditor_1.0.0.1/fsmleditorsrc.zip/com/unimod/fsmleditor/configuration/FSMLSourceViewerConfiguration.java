/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsmleditor.configuration;

import org.eclipse.jface.text.DefaultIndentLineAutoEditStrategy;
import org.eclipse.jface.text.IAutoEditStrategy;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextDoubleClickStrategy;
import org.eclipse.jface.text.ITextHover;
import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.contentassist.ContentAssistant;
import org.eclipse.jface.text.contentassist.IContentAssistant;
import org.eclipse.jface.text.presentation.IPresentationReconciler;
import org.eclipse.jface.text.presentation.PresentationReconciler;
import org.eclipse.jface.text.rules.BufferedRuleBasedScanner;
import org.eclipse.jface.text.rules.DefaultDamagerRepairer;
import org.eclipse.jface.text.rules.Token;
import org.eclipse.jface.text.source.IAnnotationHover;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.text.source.SourceViewerConfiguration;
import org.eclipse.swt.graphics.RGB;

import com.unimod.fsmleditor.FSMLEditorPlugin;
import com.unimod.fsmleditor.configuration.scanner.FSMLPartitionScanner;

/**
 * Configuration for an SourceViewer which shows FSML code.
 */
public class FSMLSourceViewerConfiguration extends SourceViewerConfiguration {
	
	/**
	 * Single token scanner.
	 */
	static class SingleTokenScanner extends BufferedRuleBasedScanner {
		public SingleTokenScanner(TextAttribute attribute) {
			setDefaultReturnToken(new Token(attribute));
		}
	}

	public FSMLSourceViewerConfiguration() {
	}
	
	/* (non-Javadoc)
	 * Method declared on SourceViewerConfiguration
	 */
	@Override
    public IAnnotationHover getAnnotationHover(ISourceViewer sourceViewer) {
		return new FSMLAnnotationHover();
	}
		
	/*
	 * @see org.eclipse.jface.text.source.SourceViewerConfiguration#getAutoEditStrategies(org.eclipse.jface.text.source.ISourceViewer, java.lang.String)
	 */
	@Override
    public IAutoEditStrategy[] getAutoEditStrategies(ISourceViewer sourceViewer, String contentType) {
		IAutoEditStrategy strategy = (IDocument.DEFAULT_CONTENT_TYPE.equals(contentType) ? new FSMLAutoIndentStrategy() : new DefaultIndentLineAutoEditStrategy());
		return new IAutoEditStrategy[] { strategy };
	}
	
	/*
	 * @see org.eclipse.jface.text.source.SourceViewerConfiguration#getConfiguredDocumentPartitioning(org.eclipse.jface.text.source.ISourceViewer)
	 */
	@Override
    public String getConfiguredDocumentPartitioning(ISourceViewer sourceViewer) {
		return FSMLEditorPlugin.FSML_PARTITIONING;
	}
	
	/* (non-Javadoc)
	 * Method declared on SourceViewerConfiguration
	 */
	@Override
    public String[] getConfiguredContentTypes(ISourceViewer sourceViewer) {
		return new String[] { IDocument.DEFAULT_CONTENT_TYPE, FSMLPartitionScanner.FSML_DOC, FSMLPartitionScanner.FSML_MULTILINE_COMMENT };
	}
	
	/* (non-Javadoc)
	 * Method declared on SourceViewerConfiguration
	 */
	@Override
    public IContentAssistant getContentAssistant(ISourceViewer sourceViewer) {

		ContentAssistant assistant= new ContentAssistant();
		assistant.setDocumentPartitioning(getConfiguredDocumentPartitioning(sourceViewer));
		assistant.setContentAssistProcessor(new FSMLAssistProcessor(), IDocument.DEFAULT_CONTENT_TYPE);
		assistant.setContentAssistProcessor(new FSMLDocCompletionProcessor(), FSMLPartitionScanner.FSML_DOC);

		assistant.enableAutoActivation(true);
		assistant.setAutoActivationDelay(500);
		assistant.setProposalPopupOrientation(IContentAssistant.PROPOSAL_OVERLAY);
		assistant.setContextInformationPopupOrientation(IContentAssistant.CONTEXT_INFO_ABOVE);
		assistant.setContextInformationPopupBackground(FSMLEditorPlugin.getFSMLColorProvider().getColor(new RGB(150, 150, 0)));

		return assistant;
	}
	
	/* (non-Javadoc)
	 * Method declared on SourceViewerConfiguration
	 */
	@Override
    public String[] getDefaultPrefixes(ISourceViewer sourceViewer, String contentType) {
		return (IDocument.DEFAULT_CONTENT_TYPE.equals(contentType) ? new String[] {"//"} : null);
	}
	
	/* (non-Javadoc)
	 * Method declared on SourceViewerConfiguration
	 */
	@Override
    public ITextDoubleClickStrategy getDoubleClickStrategy(ISourceViewer sourceViewer, String contentType) {
		return new FSMLDoubleClickSelector();
	}
	
	/* (non-Javadoc)
	 * Method declared on SourceViewerConfiguration
	 */
	@Override
    public String[] getIndentPrefixes(ISourceViewer sourceViewer, String contentType) {
		return new String[] { "\t", "    " };
	}
	
	/* (non-Javadoc)
	 * Method declared on SourceViewerConfiguration
	 */
	@Override
    public IPresentationReconciler getPresentationReconciler(ISourceViewer sourceViewer) {

		FSMLColorProvider provider = FSMLEditorPlugin.getFSMLColorProvider();
		PresentationReconciler reconciler = new PresentationReconciler();
		reconciler.setDocumentPartitioning(getConfiguredDocumentPartitioning(sourceViewer));
		
		DefaultDamagerRepairer dr = new DefaultDamagerRepairer(FSMLEditorPlugin.getFSMLCodeScanner());
		reconciler.setDamager(dr, IDocument.DEFAULT_CONTENT_TYPE);
		reconciler.setRepairer(dr, IDocument.DEFAULT_CONTENT_TYPE);
		
		dr = new DefaultDamagerRepairer(FSMLEditorPlugin.getFSMLDocScanner());
		reconciler.setDamager(dr, FSMLPartitionScanner.FSML_DOC);
		reconciler.setRepairer(dr, FSMLPartitionScanner.FSML_DOC);

		dr = new DefaultDamagerRepairer(new SingleTokenScanner(new TextAttribute(provider.getColor(FSMLColorProvider.MULTI_LINE_COMMENT))));
		reconciler.setDamager(dr, FSMLPartitionScanner.FSML_MULTILINE_COMMENT);
		reconciler.setRepairer(dr, FSMLPartitionScanner.FSML_MULTILINE_COMMENT);

		return reconciler;
	}
	
	/* (non-Javadoc)
	 * Method declared on SourceViewerConfiguration
	 */
	@Override
    public int getTabWidth(ISourceViewer sourceViewer) {
		return 4;
	}
	
	/* (non-Javadoc)
	 * Method declared on SourceViewerConfiguration
	 */
	@Override
    public ITextHover getTextHover(ISourceViewer sourceViewer, String contentType) {
		return new FSMLTextHover();
	}
}
