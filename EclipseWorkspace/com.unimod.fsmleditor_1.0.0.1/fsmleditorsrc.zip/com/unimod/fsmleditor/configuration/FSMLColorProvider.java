/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsmleditor.configuration;


import java.util.*;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Display;

/**
 * Manager for colors used in the FSML editor
 */
public class FSMLColorProvider {

	public static final RGB MULTI_LINE_COMMENT 	= new RGB(63, 127, 95);
	public static final RGB SINGLE_LINE_COMMENT = new RGB(63, 127, 95);
	public static final RGB KEYWORD 			= new RGB(127, 0, 85);
	public static final RGB TYPE 				= new RGB(127, 0, 85);
	public static final RGB STRING 				= new RGB(42, 0, 255);
	public static final RGB DEFAULT 			= new RGB(0, 0, 0);
	public static final RGB FSMLDOC_KEYWORD 	= new RGB(127, 159, 191);
	public static final RGB FSMLDOC_HTML 		= new RGB(127, 127, 159);
	public static final RGB FSMLDOC_LINK 		= new RGB(63, 63, 191);
	public static final RGB FSMLDOC_DEFAULT 	= new RGB(63, 95, 191);

	protected Map<RGB, Color> fColorTable= new HashMap<RGB, Color>(10);

	/**
	 * Release all of the color resources held onto by the receiver.
	 */	
	public void dispose() {
		Iterator<Color> e = fColorTable.values().iterator();
		while (e.hasNext()) {
			 e.next().dispose();
		}
	}
	
	/**
	 * Return the color that is stored in the color table under the given RGB
	 * value.
	 * 
	 * @param rgb the RGB value
	 * @return the color stored in the color table for the given RGB value
	 */
	public Color getColor(RGB rgb) {
		Color color= fColorTable.get(rgb);
		if (color == null) {
			color= new Color(Display.getCurrent(), rgb);
			fColorTable.put(rgb, color);
		}
		return color;
	}
}
