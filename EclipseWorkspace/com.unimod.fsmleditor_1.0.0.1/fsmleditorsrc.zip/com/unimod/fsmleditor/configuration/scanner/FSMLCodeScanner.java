/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsmleditor.configuration.scanner;


import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.rules.*;
import org.eclipse.swt.SWT;

import com.unimod.fsml.FSMLTokens;
import com.unimod.fsmleditor.configuration.FSMLColorProvider;

/**
 * A FSML code scanner.
 */
public class FSMLCodeScanner extends RuleBasedScanner {

	/**
	 * Creates a FSML code scanner with the given color provider.
	 * 
	 * @param provider the color provider
	 */
	public FSMLCodeScanner(FSMLColorProvider provider) {

		IToken keyword = new Token(new TextAttribute(provider.getColor(FSMLColorProvider.KEYWORD), null, SWT.BOLD));
		IToken type = new Token(new TextAttribute(provider.getColor(FSMLColorProvider.TYPE), null, SWT.BOLD));
		IToken string = new Token(new TextAttribute(provider.getColor(FSMLColorProvider.STRING)));
		IToken comment = new Token(new TextAttribute(provider.getColor(FSMLColorProvider.SINGLE_LINE_COMMENT)));
		IToken other = new Token(new TextAttribute(provider.getColor(FSMLColorProvider.DEFAULT)));

		List<IRule> rules = new ArrayList<IRule>();

		// Add rule for single line comments.
		rules.add(new EndOfLineRule("//", comment));

		// Add rule for strings and character constants.
		rules.add(new SingleLineRule("\"", "\"", string, '\\'));
		rules.add(new SingleLineRule("'", "'", string, '\\'));

		// Add generic whitespace rule.
		rules.add(new WhitespaceRule(new FSMLWhitespaceDetector()));

		// Add word rule for keywords, types, and constants.
		WordRule wordRule = new WordRule(new FSMLWordDetector(), other);
		for (int i = 0; i < FSMLTokens.KEYWORDS.length; i++)
			wordRule.addWord(FSMLTokens.KEYWORDS[i], keyword);
		for (int i = 0; i < FSMLTokens.TYPES.length; i++)
			wordRule.addWord(FSMLTokens.TYPES[i], type);
		for (int i = 0; i < FSMLTokens.BOOL_CONSTS.length; i++)
			wordRule.addWord(FSMLTokens.BOOL_CONSTS[i], type);
		rules.add(wordRule);

		IRule[] result = new IRule[rules.size()];
		rules.toArray(result);
		setRules(result);
	}
}
