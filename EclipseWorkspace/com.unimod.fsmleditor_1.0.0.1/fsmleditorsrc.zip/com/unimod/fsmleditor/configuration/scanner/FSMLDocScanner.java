/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsmleditor.configuration.scanner;


import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.rules.*;

import com.unimod.fsmleditor.configuration.FSMLColorProvider;

/**
 * A rule based FSMLDoc scanner.
 */
public class FSMLDocScanner extends RuleBasedScanner {

	/**
	 * A key word detector.
	 */
	static class FSMLDocWordDetector implements IWordDetector {

	/* (non-Javadoc)
	 * Method declared on IWordDetector
	 */
		public boolean isWordStart(char c) {
			return (c == '@');
		}

		/* (non-Javadoc)
	 	* Method declared on IWordDetector
	 	*/
		public boolean isWordPart(char c) {
			return Character.isLetter(c);
		}
	}

	private static String[] fgKeywords = { "@author", "@deprecated", "@exception", "@param", "@return", "@see", "@serial", "@serialData", "@serialField", "@since", "@throws", "@version" }; //$NON-NLS-12$ //$NON-NLS-11$ //$NON-NLS-10$ //$NON-NLS-7$ //$NON-NLS-9$ //$NON-NLS-8$ //$NON-NLS-6$ //$NON-NLS-5$ //$NON-NLS-4$ //$NON-NLS-3$ //$NON-NLS-2$ //$NON-NLS-1$

	/**
	 * Create a new FSMLdoc scanner for the given color provider.
	 * 
	 * @param provider the color provider
	 */
	 public FSMLDocScanner(FSMLColorProvider provider) {
		super();

		IToken keyword = new Token(new TextAttribute(provider.getColor(FSMLColorProvider.FSMLDOC_KEYWORD)));
		IToken html = new Token(new TextAttribute(provider.getColor(FSMLColorProvider.FSMLDOC_HTML)));
		IToken link = new Token(new TextAttribute(provider.getColor(FSMLColorProvider.FSMLDOC_LINK)));

		List<IRule> list = new ArrayList<IRule>();

		// Add rule for tags.
		list.add(new SingleLineRule("<", ">", html)); //$NON-NLS-2$ //$NON-NLS-1$

		// Add rule for links.
		list.add(new SingleLineRule("{", "}", link)); //$NON-NLS-2$ //$NON-NLS-1$

		// Add generic whitespace rule.
		list.add(new WhitespaceRule(new FSMLWhitespaceDetector()));

		// Add word rule for keywords.
		WordRule wordRule = new WordRule(new FSMLDocWordDetector());
		for (int i = 0; i < fgKeywords.length; i++)
			wordRule.addWord(fgKeywords[i], keyword);
		list.add(wordRule);

		IRule[] result = new IRule[list.size()];
		list.toArray(result);
		setRules(result);
	}
}
