/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsmleditor.action;


import org.eclipse.jface.action.*;
import org.eclipse.ui.*;
import org.eclipse.ui.editors.text.TextEditorActionContributor;
import org.eclipse.ui.texteditor.*;

import com.unimod.fsmleditor.FSMLEditorMessages;

/**
 * Contributes interesting Java actions to the desktop's Edit menu and the toolbar.
 * 
 * @author Ivan Lagunov
 */
public class FSMLActionContributor extends TextEditorActionContributor {

	protected RetargetTextEditorAction fContentAssistProposal;
	protected RetargetTextEditorAction fContentAssistTip;
	protected TextEditorAction fTogglePresentation;

	/**
	 * Default constructor.
	 */
	public FSMLActionContributor() {
		super();
		fContentAssistProposal= new RetargetTextEditorAction(FSMLEditorMessages.getResourceBundle(), "ContentAssistProposal.");
		fContentAssistProposal.setActionDefinitionId(ITextEditorActionDefinitionIds.CONTENT_ASSIST_PROPOSALS); 
		fContentAssistTip= new RetargetTextEditorAction(FSMLEditorMessages.getResourceBundle(), "ContentAssistTip.");
		fContentAssistTip.setActionDefinitionId(ITextEditorActionDefinitionIds.CONTENT_ASSIST_CONTEXT_INFORMATION);
//		fTogglePresentation= new PresentationsAction();
	}
	
	/*
	 * @see IEditorActionBarContributor#init(IActionBars)
	 */
	@Override
    public void init(IActionBars bars) {
		super.init(bars);
		
		IMenuManager menuManager= bars.getMenuManager();
		IMenuManager editMenu= menuManager.findMenuUsingPath(IWorkbenchActionConstants.M_EDIT);
		if (editMenu != null) {
			editMenu.add(new Separator());
			editMenu.add(fContentAssistProposal);
			editMenu.add(fContentAssistTip);
		}	
		
//		IToolBarManager toolBarManager= bars.getToolBarManager();
//		if (toolBarManager != null) {
//			toolBarManager.add(new Separator());
//			toolBarManager.add(fTogglePresentation);
//		}
	}
	
	private void doSetActiveEditor(IEditorPart part) {
		super.setActiveEditor(part);

		ITextEditor editor = null;
		if (part instanceof ITextEditor) {
			editor = (ITextEditor) part;
		}

		fContentAssistProposal.setAction(getAction(editor, "ContentAssistProposal"));
		fContentAssistTip.setAction(getAction(editor, "ContentAssistTip"));

//		fTogglePresentation.setEditor(editor);
//		fTogglePresentation.update();
	}
	
	/*
	 * @see IEditorActionBarContributor#setActiveEditor(IEditorPart)
	 */
	@Override
    public void setActiveEditor(IEditorPart part) {
		super.setActiveEditor(part);
		doSetActiveEditor(part);
	}
	
	/*
	 * @see IEditorActionBarContributor#dispose()
	 */
	@Override
    public void dispose() {
		doSetActiveEditor(null);
		super.dispose();
	}
}
