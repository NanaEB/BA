/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsmleditor.action;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IEditorActionDelegate;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.texteditor.ITextEditor;

public class GenerateUniModXmlActionDelegate implements IEditorActionDelegate {

	private ITextEditor editor;
	
	public void selectionChanged(IAction action, ISelection selection) {
	}

	public void run(IAction action) {
		GenerateUniModXmlAction generateAction = new GenerateUniModXmlAction(editor);
		generateAction.run();
	}

	public void setActiveEditor(IAction action, IEditorPart targetEditor) {
		if (targetEditor instanceof ITextEditor) {
			editor = (ITextEditor) targetEditor;
		} else {
			editor = null;
		}
	}
}
