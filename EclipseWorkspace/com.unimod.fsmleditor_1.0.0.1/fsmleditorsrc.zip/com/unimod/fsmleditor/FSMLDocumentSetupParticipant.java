/*
 * Copyright (C) 2005 eVelopers Corporation
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package com.unimod.fsmleditor;

import org.eclipse.core.filebuffers.IDocumentSetupParticipant;

import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IDocumentExtension3;
import org.eclipse.jface.text.IDocumentPartitioner;
import org.eclipse.jface.text.rules.FastPartitioner;

import com.unimod.fsmleditor.configuration.scanner.FSMLPartitionScanner;

/**
 * 
 */
public class FSMLDocumentSetupParticipant implements IDocumentSetupParticipant {
	
	/**
	 */
	public FSMLDocumentSetupParticipant() {
	}

	/*
	 * @see org.eclipse.core.filebuffers.IDocumentSetupParticipant#setup(org.eclipse.jface.text.IDocument)
	 */
	public void setup(IDocument document) {
		if (document instanceof IDocumentExtension3) {
			IDocumentExtension3 extension3 = (IDocumentExtension3) document;
			IDocumentPartitioner partitioner = new FastPartitioner(FSMLEditorPlugin.getFSMLPartitionScanner(), FSMLPartitionScanner.FSML_PARTITION_TYPES);
			extension3.setDocumentPartitioner(FSMLEditorPlugin.FSML_PARTITIONING, partitioner);
			partitioner.connect(document);
		}
	}
}
